﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace FirstWindow
{

    public partial class Form1 : Form
    {
        int numbervalue = 0;
        double percent = 0;
        string indata = "";
        public Form1()
        {
            InitializeComponent();
            getPorts();
            timer.Enabled = true;
        }

        private void timer_Tick(object sender, EventArgs e)
        {

            if (serialPort1.IsOpen == true)
            {
                serialPort1.Write("n" + "\n\r");
                indata = serialPort1.ReadExisting();
                if (indata != "") indata = indata.Substring(1);
            }
            if (indata != "" && !indata.Contains("n") && !indata.Contains("s") && !indata.Contains("e"))
            {
                rpm.ResetText();
                rpm.Text = indata;
            }
        }

        //private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        //{
        //    SerialPort sp = (SerialPort)sender;
        //    indata = sp.ReadExisting();
        //}

        private void button_Click(object sender, EventArgs e)
        {
            timer.Stop();
            pwm.ResetText();
            numbervalue = (int)number.Value;                //input kasztolása int-té
            percent = (numbervalue * 100) / 19621;
            string valuestring = numbervalue.ToString();    //konvertálás sztinggé
            string percentstring = percent.ToString();      //konvertálás sztinggé
            pwm.Text = percentstring;
            if (serialPort1.IsOpen == true)
            {
                serialPort1.Write("s"+ valuestring + "e" + "\n\r");
            }
            timer.Start();
        }

        void getPorts()
        {
            string[] ports = SerialPort.GetPortNames();
            comboBox1.Items.AddRange(ports);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            closeport.Enabled = true;
            if (comboBox1.Text == "") MessageBox.Show("Válaszd ki a portot!");
            else if (!serialPort1.IsOpen)
            {
                serialPort1.PortName = comboBox1.Text;
                serialPort1.BaudRate = 9600;
                serialPort1.Parity = Parity.None;
                serialPort1.StopBits = StopBits.One;
                serialPort1.DataBits = 8;
                serialPort1.Handshake = Handshake.None;
                serialPort1.ReadTimeout = 4000;
                serialPort1.WriteTimeout = 6000;
                try
                {
                    serialPort1.Open();
                }
                catch (UnauthorizedAccessException ex)
                {
                    MessageBox.Show(ex.Message);
                }

                if (serialPort1.IsOpen) number.Enabled = true;
            }
        }


        private void closeport_Click(object sender, EventArgs e)
        {
            number.Enabled = false;
            timer.Stop();
            rpm.ResetText();
            pwm.ResetText();
            if (serialPort1.IsOpen == true)
            {
                serialPort1.Write("s" + "0" + "e" + "\n\r");
            }
            serialPort1.Close();
        }


        void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            number.Enabled = false;
            timer.Stop();
            rpm.ResetText();
            pwm.ResetText();
            if (serialPort1.IsOpen == true)
            {
                serialPort1.Write("s" + "0" + "e" + "\n\r");
            }
            serialPort1.Close();
        }
    }
}

